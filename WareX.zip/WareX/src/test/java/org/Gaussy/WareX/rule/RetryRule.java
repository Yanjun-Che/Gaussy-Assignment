package org.Gaussy.WareX.rule;

import org.Gaussy.WareX.annotation.Retry;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public class RetryRule implements TestRule {
	@Override
	public Statement apply(Statement statement, Description description) {
		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				Throwable retryThrowable = null;
				Retry retry =description.getAnnotation(Retry.class);
				if (retry != null) {
					System.out.println("retryラベルが見つかりました。");
					int times = retry.times();
					System.out.println(times);
					for (int i=0; i<times; i++) {
						try {
							statement.evaluate();
							return;
						} catch (Throwable t) {
							retryThrowable = t;
							System.err.println("テストケース"+description.getMethodName()+"は　"+(i+1)+"次目　試しています。");
						}
					}
					
					System.err.println("テストケース"+description.getMethodName()+"は"+times+"回実行した後、最終的に失敗しました。");
					throw retryThrowable;
				} else {
					System.out.println("retryラベルが見つかりません。");
					statement.evaluate();
				}
			}
			
		};
	}

}