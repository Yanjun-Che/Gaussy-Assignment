package org.Gaussy.WareX.testcases;

import static org.junit.Assert.*;

import org.databene.benerator.anno.Source;
import org.databene.feed4junit.Feeder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.Gaussy.WareX.pageobject.RegistrationPage;
import org.Gaussy.WareX.annotation.Retry;
import org.Gaussy.WareX.base.BaseTestCase;

@RunWith(Feeder.class)
public class RegistrationPageTest extends BaseTestCase {
		
		RegistrationPageTest RegistrationPage;

		
		String url = "https://uat.warex.aukai.dev/";
		@Before
		public void open() {
			driver.get(url);
		}

		@Test
//		@Ignore
		@Source("./data/Registration_data.csv")
		@Retry(times=3)
		public void freeRegistraion(String email, String  companyName,String lastName, String firstName, String password,String phone, String expected) {
			RegistrationPage.freeRegistraion(email,companyName,lastName,firstName,password,phone,expected);
			String expectedText = expected;
			
			String actualText= driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/div[2]/h2")).getText();
	
			Assert.assertEquals(expectedText, actualText);
			
			fail("Not yet implemented");
		}
}