package org.Gaussy.WareX.testcases;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.Gaussy.WareX.annotation.Retry;
import org.Gaussy.WareX.base.BaseTestCase;
import org.Gaussy.WareX.pageobject.LoginPage;
import org.Gaussy.WareX.rule.RetryRule;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


public class LoginPageTest extends BaseTestCase {
	
	@Rule
	public RetryRule retryRule = new RetryRule();
	


    @Test
//	@Retry(times=3)
	public void testLogin() {

		LoginPage loginPage = new LoginPage(driver);
		loginPage.open();
		 driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);

		loginPage.clickLoginLink();
		 driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		loginPage.inputEmail("kuruma_eagle@yahoo.co.jp");
		loginPage.inputPassword("QAZwsx123");
		loginPage.clickLoginButton();

		String expectedMsg = "ログインに失敗しました。 ";

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		String actualMsg = loginPage.GetMsg();
//		assertTrue(actualMsg.contains(expectedMsg));

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		fail("Not yet implemented");
	}

}
