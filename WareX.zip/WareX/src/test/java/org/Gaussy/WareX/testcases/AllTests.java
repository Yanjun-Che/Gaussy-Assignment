package org.Gaussy.WareX.testcases;

import org.Gaussy.WareX.runner.MySuite;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(MySuite.class)
@SuiteClasses({ LoginPageTest.class, RegistrationPageTest.class })
public class AllTests {

}
