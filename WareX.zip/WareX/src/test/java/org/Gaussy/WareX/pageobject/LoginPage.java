package org.Gaussy.WareX.pageobject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
//　　このクラスの中に幾つかのエレメントと操作を含まれているかをよく考えます
//	Annotationを使って、すべてのエレメントを見つける。

	@FindBy(xpath = "/html/body/div[1]/div/div/div[1]/div[3]/div/ul[2]/li[1]/a")
	WebElement login_link;
	
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/main/div/form/div[2]/div/div[1]/input")
	WebElement email_input_box;
	
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/main/div/form/div[3]/div/div[1]/input")
	WebElement password_input_box;
	
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/main/div/form/div[5]/button")
	WebElement login_btn;
	
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/main/p")
	WebElement Fail_Msg;
	
	public void clickLoginLink() {
		login_link.click();
	}
	
	public void inputEmail(String email) {
		email_input_box.sendKeys(email);
	}
	
	public void inputPassword(String password) {
		password_input_box.sendKeys(password);
	}
	
	public void clickLoginButton() {
		login_btn.click();
	}
	
	public void GetMsg() {
		Fail_Msg.getText();
	}
	
	String url = "https://uat.warex.aukai.dev/";
	
	public void open() {
		driver.get(url);
		driver.manage().window().maximize();

	}
	
	
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);
	}
}