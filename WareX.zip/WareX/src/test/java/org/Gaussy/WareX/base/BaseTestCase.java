package org.Gaussy.WareX.base;

import java.util.concurrent.TimeUnit;

import org.Gaussy.WareX.rule.RetryRule;
import org.Gaussy.WareX.util.WebDriverManager;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.openqa.selenium.WebDriver;

public class BaseTestCase {
	public static WebDriver driver;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		driver = WebDriverManager.getWebdriver("chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		Thread.sleep(10000);
		driver.quit();
	}
	
	@Rule
	public RetryRule retryRule = new RetryRule();
	
}
