package org.Gaussy.WareX.util;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.google.common.io.Files;

public class SnapshotManager {
	
	public static void getScreenshot(String filename) {
		String path = "./image/" + filename + ".png";
		File sourceFile = ((TakesScreenshot)WebDriverManager.getWebdriver()).getScreenshotAs(OutputType.FILE);
		File targetFile = new File(path);
//		sourceFile中に保存されているピクチャーをtargetFileに保存します。
		try {
			Files.copy(sourceFile, targetFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
