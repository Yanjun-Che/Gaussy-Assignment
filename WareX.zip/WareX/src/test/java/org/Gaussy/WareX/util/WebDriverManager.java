package org.Gaussy.WareX.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WebDriverManager {
	
	static WebDriver driver;
	
	public static WebDriver getWebdriver(String browserName) {
		if ("chrome".equals(browserName)) {
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("disable-infobars");
//			System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
			driver = new ChromeDriver(chromeOptions);
		} else if ("firefox".equals(browserName)) {
//			....
			driver = new FirefoxDriver();
		} else if ("ie32".equals(browserName)) {
			System.setProperty("webdriver.ie.driver", "./driver/32/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else if ("ie64".equals(browserName)) {
			System.setProperty("webdriver.ie.driver", "./driver/64/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else {
			System.out.println("ie32，ie64，firefoxとchromeのほかに　支えられません。");
		}
		return driver;
	}
	
	public static WebDriver getWebdriver() {
		return driver;
	}
}
