package org.Gaussy.WareX.listener;

import org.Gaussy.WareX.util.SnapshotManager;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class TestCaseFailureListener extends RunListener {
	@Override
    public void testFailure(Failure failure) throws Exception {
		String filename = failure.getDescription().getTestClass().getSimpleName()
				+ "_" + failure.getDescription().getMethodName();
		SnapshotManager.getScreenshot(filename);
    }
}
