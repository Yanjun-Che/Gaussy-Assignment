package org.Gaussy.WareX.testcases;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindPageElement2 {

	public static void main(String[] args) { 

		WebDriver driver = new ChromeDriver();

		driver.get("https://uat.warex.aukai.dev/");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		 
		driver.findElement(By.cssSelector(".heap-sign-up-button-global-menu")).click();
		
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		
	

		driver.findElement(By.id("email")).sendKeys("k444ma_eagle@yahoo.co.jp");
		driver.findElement(By.id("companyName")).sendKeys("QA株式会社");
		driver.findElement(By.id("lastName")).sendKeys("QA姓");
		driver.findElement(By.id("firstName")).sendKeys("QA名");
		driver.findElement(By.id("password")).sendKeys("QAZwsx123");
		driver.findElement(By.id("phone")).sendKeys("09012345678");
		

		driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/form/div/div[3]/label/div/span")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/form/div/div[4]/button")).click();
		
		driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);

		String expectedText="ようこそWareXへ！";
		String actualText = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/div[2]/h2")).getText();
		String expectedText1="利用登録ができませんでした。";
		String actualText1 = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/form/div/p[2]")).getText();
		Assert.assertEquals(expectedText, actualText);
		Assert.assertEquals(expectedText1, actualText1);
		System.out.println(actualText);
		System.out.println(actualText1);
		}
	}

