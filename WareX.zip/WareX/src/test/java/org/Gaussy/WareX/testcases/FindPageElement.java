package org.Gaussy.WareX.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindPageElement {

	public static void main(String[] args) { 
//1.打开浏览器
		//java代码中区分大小写
		//WebDriver浏览器驱动
		//driver我们打开浏览器爹名字，这个名字可以随便起
		//等号表示赋值
		//new 新建
		//ChromeDriver Chrome浏览器驱动
		//新建一个chrome浏览器并且起个名字叫driver
		//Ctrl+shift+O导入
		WebDriver driver = new ChromeDriver();
//2.打开登录页面
//		driver.get("https://uat.warex.aukai.dev/");
		driver.get("https://uat.warex.aukai.dev/workspace/login?redirect=%2F");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		 
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[3]/div/ul[2]/li[1]/a")).click();
		
//		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		
	
//3.输入用户名
	//	driver.findElement(By.className("el-input_inner")).sendKeys("kuruma_eagle@yahoo.co.jp");
		System.out.println("Email Input");
//4.输入密码
//		driver.switchTo().frame("intercom-frame");
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/main/div/form/div[2]/div/div[1]/input")).sendKeys("kuruma_eagle@yahoo.co.jp");
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/main/div/form/div[3]/div/div[1]/input")).sendKeys("QAZwsx123");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/main/div/form/div[2]/div/div[1]/input")).sendKeys("kuruma_eagle@yahoo.co.jp");
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/main/div/form/div[3]/div/div[1]/input")).sendKeys("QAZwsx123");
		
//5.点击登录按钮
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/main/div/form/div[5]/button")).click();
	}

}
