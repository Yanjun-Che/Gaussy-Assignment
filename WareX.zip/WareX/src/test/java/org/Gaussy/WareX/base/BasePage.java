package org.Gaussy.WareX.base;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

public class BasePage {

	protected WebDriver driver;
	
	public BasePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void sendKeys(WebElement element, String keys) {
		element.clear();
		element.sendKeys(keys);
		
	}
	
	public void click(WebElement element) {

		try {
		element.click();
		} catch (StaleElementReferenceException e) {

			new Actions(driver).click(element).perform();

		}
		

	}

}
