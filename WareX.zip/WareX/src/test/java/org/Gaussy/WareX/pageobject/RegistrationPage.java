package org.Gaussy.WareX.pageobject;

import org.Gaussy.WareX.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPage extends BasePage {
	
	public RegistrationPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(css=".heap-sign-up-button-global-menu")
	@CacheLookup	//If this element can be used frequently, add this comments for Cache
	WebElement free_registration_button;
	
	@FindBy(id="email")
	@CacheLookup
	WebElement email_input_box;
	
	@FindBy(id="companyName")
	@CacheLookup
	WebElement companyName_input_box;
	
	@FindBy(id="lastName")
	@CacheLookup
	WebElement lastName_input_box;
	
	@FindBy(id="firstName")
	@CacheLookup
	WebElement firstName_input_box;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement password_input_box;
	
	@FindBy(id="phone")
	@CacheLookup
	WebElement phone_input_box;
	
	@FindBy(xpath="/html/body/div[1]/div/div/div[3]/div[2]/div/form/div/div[3]/label/div/span")
	@CacheLookup
	WebElement check_box;
	
	@FindBy(xpath="/html/body/div[1]/div/div/div[3]/div[2]/div/form/div/div[4]/button")
	@CacheLookup
	WebElement register_button;
	
	public void freeRegistraion(String email, String  companyName,String lastName, String firstName, String password,String phone) {
		
		click(free_registration_button);	
		
		sendKeys(email_input_box,email);
		sendKeys(companyName_input_box,companyName);
		sendKeys(lastName_input_box,lastName);
		sendKeys(firstName_input_box,firstName);
		sendKeys(password_input_box,password);
		sendKeys(phone_input_box,phone);

		click(check_box);

		click(register_button);

//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		WebElement actual= driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/div[2]/div/div[2]/h2"));
//		String actualText=actual.getText();
		}

	String url = "https://uat.warex.aukai.dev/";
	
	public void open() {
		driver.get(url);
	

	}
		
		
}

